import { HttpException } from '@nestjs/common';
import { type MonoTypeOperatorFunction } from 'rxjs';
/**
 * Removes the files multer stored for `req` when the route's pipes reject
 * the request (e.g. `ParseFilePipe`): the route handler never sees them, and
 * nothing else would remove them. They are removed once the response has
 * been sent, as an exception filter may still use (or remove) them.
 */
export declare function removeFilesOnPipeRejection<T>(storage: any, req: any, res: any): MonoTypeOperatorFunction<T>;
export declare function transformException(error: (Error & {
    field?: string;
    code?: string;
}) | undefined): HttpException | (Error & {
    field?: string;
    code?: string;
}) | undefined;
