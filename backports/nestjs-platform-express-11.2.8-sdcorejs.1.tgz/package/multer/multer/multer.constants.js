"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.busboyExceptions = exports.multerExceptions = void 0;
exports.multerExceptions = {
    // from https://github.com/expressjs/multer/blob/master/lib/multer-error.js
    LIMIT_PART_COUNT: 'Too many parts',
    LIMIT_FILE_SIZE: 'File too large',
    LIMIT_FILE_COUNT: 'Too many files',
    LIMIT_FIELD_KEY: 'Field name too long',
    LIMIT_FIELD_VALUE: 'Field value too long',
    LIMIT_FIELD_COUNT: 'Too many fields',
    LIMIT_UNEXPECTED_FILE: 'Unexpected file field',
    MISSING_FIELD_NAME: 'Field name missing',
    LIMIT_FIELD_NESTING: 'Field name nesting too deep',
    LIMIT_FIELD_ARRAY_INDEX: 'Field name array index too large',
    INVALID_FIELD_NAME: 'Invalid field name',
    // STREAM_DESTROYED is left out on purpose: it is raised by the storage
    // engine after the file stream was destroyed, not by the request, so it
    // stays a 500.
};
exports.busboyExceptions = {
    // from https://github.com/mscdex/busboy/blob/master/lib/types/multipart.js
    MULTIPART_BOUNDARY_NOT_FOUND: 'Multipart: Boundary not found',
    MULTIPART_MALFORMED_PART_HEADER: 'Malformed part header',
    MULTIPART_UNEXPECTED_END_OF_FORM: 'Unexpected end of form',
    MULTIPART_UNEXPECTED_END_OF_FILE: 'Unexpected end of file',
};
