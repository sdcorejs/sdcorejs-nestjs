"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeFilesOnPipeRejection = removeFilesOnPipeRejection;
exports.transformException = transformException;
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const stream_1 = require("stream");
const multer_constants_1 = require("./multer.constants");
/**
 * Set on a request whose pipes rejected it, by the router of
 * `@nestjs/core` (see `markRejectedByPipes()` there). Read through the
 * registered symbol rather than an import, so this package still loads with
 * a version of `@nestjs/core` that does not set it.
 */
const REJECTED_BY_PIPES = Symbol.for('nestjs:rejected-by-pipes');
function isRejectedByPipes(req) {
    return req?.[REJECTED_BY_PIPES] === true;
}
/**
 * Removes the files multer stored for `req` when the route's pipes reject
 * the request (e.g. `ParseFilePipe`): the route handler never sees them, and
 * nothing else would remove them. They are removed once the response has
 * been sent, as an exception filter may still use (or remove) them.
 */
function removeFilesOnPipeRejection(storage, req, res) {
    return (0, rxjs_1.catchError)(err => {
        if (isRejectedByPipes(req)) {
            (0, stream_1.finished)(res, () => {
                for (const file of storedFiles(req)) {
                    try {
                        storage._removeFile(req, file, () => undefined);
                    }
                    catch {
                        // The request has failed already.
                    }
                }
            });
        }
        return (0, rxjs_1.throwError)(() => err);
    });
}
function storedFiles(req) {
    const { file, files } = req;
    if (file) {
        return [file];
    }
    return Array.isArray(files) ? files : Object.values(files ?? {}).flat();
}
// Multer may add in a 'field' property to the error
// https://github.com/expressjs/multer/blob/aa42bea6ac7d0cb8fcb279b15a7278cda805dc63/lib/multer-error.js#L19
function transformException(error) {
    if (!error || error instanceof common_1.HttpException) {
        return error;
    }
    // Multer identifies its errors by `code`, while the messages may change
    // between releases (e.g. "Unexpected field" became "Unexpected file field")
    const exception = isMulterExceptionCode(error.code)
        ? multer_constants_1.multerExceptions[error.code]
        : error.message;
    switch (exception) {
        case multer_constants_1.multerExceptions.LIMIT_FILE_SIZE:
            return new common_1.PayloadTooLargeException(error.message);
        case multer_constants_1.multerExceptions.LIMIT_FILE_COUNT:
        case multer_constants_1.multerExceptions.LIMIT_FIELD_KEY:
        case multer_constants_1.multerExceptions.LIMIT_FIELD_VALUE:
        case multer_constants_1.multerExceptions.LIMIT_FIELD_COUNT:
        case multer_constants_1.multerExceptions.LIMIT_FIELD_NESTING:
        case multer_constants_1.multerExceptions.LIMIT_FIELD_ARRAY_INDEX:
        case multer_constants_1.multerExceptions.INVALID_FIELD_NAME:
        case multer_constants_1.multerExceptions.LIMIT_UNEXPECTED_FILE:
        case multer_constants_1.multerExceptions.LIMIT_PART_COUNT:
        case multer_constants_1.multerExceptions.MISSING_FIELD_NAME:
            if (error.field) {
                return new common_1.BadRequestException(`${error.message} - ${error.field}`);
            }
            return new common_1.BadRequestException(error.message);
        case multer_constants_1.busboyExceptions.MULTIPART_BOUNDARY_NOT_FOUND:
            return new common_1.BadRequestException(error.message);
        case multer_constants_1.busboyExceptions.MULTIPART_MALFORMED_PART_HEADER:
        case multer_constants_1.busboyExceptions.MULTIPART_UNEXPECTED_END_OF_FORM:
        case multer_constants_1.busboyExceptions.MULTIPART_UNEXPECTED_END_OF_FILE:
            return new common_1.BadRequestException(`Multipart: ${error.message}`);
    }
    return error;
}
function isMulterExceptionCode(code) {
    return (typeof code === 'string' &&
        Object.prototype.hasOwnProperty.call(multer_constants_1.multerExceptions, code));
}
